// App router — top-level state machine.

const { useState: useStateA, useEffect: useEffectA } = React;

function App() {
  useEffectA(() => { window.applyTheme(); }, []);

  const [route, setRoute] = useStateA('landing');     // landing | wizard | results | pricing | audit
  const [wizardIdx, setWizardIdx] = useStateA(0);
  const [values, setValues] = useStateA('financial');
  const [tier, setTier] = useStateA('free');          // free | pack | founders

  // Auth — purchase-first; account materializes implicitly on Stripe success.
  const [auth, setAuth] = useStateA({
    state: 'anonymous',                                // anonymous | signedIn
    email: null,
    creditsAudit: 0,                                   // audit credits remaining
  });

  // Modals
  const [modal, setModal] = useStateA(null);          // null | 'checkout' | 'signin' | 'magic-sent'
  const [pendingTier, setPendingTier] = useStateA(null);

  const [wizard, setWizard] = useStateA({
    address: { address: '1242 Spruce St, Boulder CO 80302', utility: 'Xcel Energy', tariff: 'RE-TOU residential', hold: '10' },
    usage:   { method: 'manual', kwh: 11200, bill: 168, upcoming: ['EV'] },
    roof:    { size: 7.2, tilt: '25', azimuth: 'S', shading: 'light' },
    battery: { include: true, capacity: 13.5, dispatch: 'self', critical: ['Fridge', 'Furnace fan', 'Internet'] },
    finance: { method: 'cash', term: '15', apr: '6.99', dealerFee: 'no', escalator: '2.9', discount: '5.5' },
  });

  const [audit, setAudit] = useStateA({
    stage: 'upload',                                   // upload | extracting | review | report
    fileName: null,
    extracted: null,
  });

  const goLanding = () => { setRoute('landing'); window.scrollTo(0, 0); };
  const goWizard  = () => { setRoute('wizard'); setWizardIdx(0); window.scrollTo(0, 0); };
  const goResults = () => { setRoute('results'); window.scrollTo(0, 0); };
  const goPricing = () => { setRoute('pricing'); window.scrollTo(0, 0); };
  const goAudit   = () => { setAudit(a => ({ ...a, stage: 'upload' })); setRoute('audit'); window.scrollTo(0, 0); };

  // The conversion-critical action. Called from any "Unlock $79" CTA.
  const onUpgradeRequested = (which = 'pack') => { setPendingTier(which); setModal('checkout'); };

  // Anonymous → signedIn + tier set + audit credits attached.
  const onCheckoutSuccess = (email) => {
    const nextTier = pendingTier || 'pack';
    const credits = nextTier === 'founders' ? 3 : 1;
    setAuth({ state: 'signedIn', email, creditsAudit: credits });
    setTier(nextTier);
    setPendingTier(null);
    setModal(null);
  };

  // Returning user — magic-link mock.
  const onSignInRequested = () => setModal('signin');
  const onMagicLinkSent = () => setModal('magic-sent');
  const onMagicLinkClicked = (email) => {
    // Mock: assume returning user already has Decision Pack with 1 credit.
    setAuth({ state: 'signedIn', email, creditsAudit: 1 });
    setTier('pack');
    setModal(null);
  };

  const onSignOut = () => {
    setAuth({ state: 'anonymous', email: null, creditsAudit: 0 });
    setTier('free');
  };

  // Audit entry — gated by signed-in + has credits, otherwise route to checkout.
  const onAuditRequested = () => {
    if (auth.state !== 'signedIn') { onUpgradeRequested('pack'); return; }
    if (auth.creditsAudit < 1) { onUpgradeRequested('pack'); return; }
    goAudit();
  };

  const onAuditComplete = () => {
    setAuth(a => ({ ...a, creditsAudit: Math.max(0, a.creditsAudit - 1) }));
    setAudit(a => ({ ...a, stage: 'report' }));
  };

  const navProps = {
    auth, onSignInRequested, onSignOut,
    tier, setTier,                                      // mock tier switcher remains for prototype
    values, setValues,
  };

  let screen;
  if (route === 'landing') {
    screen = <ScreenLanding {...navProps} onStart={goWizard} onAudit={onAuditRequested} onPricing={goPricing} route={route} setRoute={setRoute} />;
  } else if (route === 'wizard') {
    screen = <ScreenWizard wizard={wizard} setWizard={setWizard} idx={wizardIdx} setIdx={setWizardIdx} onFinish={goResults} onCancel={goLanding} />;
  } else if (route === 'pricing') {
    screen = <ScreenPricing tier={tier} setTier={setTier} onCancel={() => setRoute(wizard ? 'results' : 'landing')} onAfterChoose={(t) => { onUpgradeRequested(t || 'pack'); }} />;
  } else if (route === 'audit') {
    screen = <ScreenAudit audit={audit} setAudit={setAudit} {...navProps}
      onCancel={goResults} onComplete={onAuditComplete} />;
  } else {
    screen = <ScreenResults {...navProps}
      onCancel={goLanding} onAudit={onAuditRequested} onUpgrade={() => onUpgradeRequested('pack')} />;
  }

  return (
    <>
      {screen}
      <CheckoutModal
        open={modal === 'checkout'}
        tier={pendingTier || 'pack'}
        onClose={() => { setModal(null); setPendingTier(null); }}
        onSuccess={onCheckoutSuccess}
        onSwitchToSignIn={() => setModal('signin')}
      />
      <SignInModal
        open={modal === 'signin'}
        onClose={() => setModal(null)}
        onSent={onMagicLinkSent}
      />
      <MagicLinkSentModal
        open={modal === 'magic-sent'}
        onClose={() => setModal(null)}
        onClicked={onMagicLinkClicked}
      />
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
